---
author: Niennor
type: post
date: 2011-09-07T04:14:22+00:00
draft: true
url: /?p=155
tumblr_elclaustro-blog_permalink:
  - https://elclaustro-blog.tumblr.com/post/9897210993/imperdible-para-la-comunidad-claustriana-y-todos
tumblr_elclaustro-blog_id:
  - 9897210993
tumblr_attribution:
  - https://www.youtube.com/
categories:
  - Noticias
  - Sin categoría
format: video

---
Imperdible para la comunidad claustriana y todos los amigos, así se rien un rato!

<div class="attribution">
  (<span>Source:</span> <a href="https://www.youtube.com/">https://www.youtube.com/</a>)
</div>
---
title: Dark Corp TV – Temporada 2 Episodio 14
author: Niennor
type: post
date: 2022-03-29T16:06:47+00:00
url: /noticias/dark-corp-tv-temporada-2-episodio-14/
featured_image: /wp-content/uploads/2022/03/277555545_509345807550929_4471107181600591093_n.jpg
categories:
  - Noticias
tags:
  - chile
  - Entrevista
  - goth
  - gótico

---
 

Dark Corp vuelve y es un placer para nosotros poder compartir un trabajo de altísima calidad, de quienes continúan con un espíritu underground, dark y por sobre todo **profesional y apasionado**.<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">

<div class="wp-block-embed__wrapper">
</div></figure>
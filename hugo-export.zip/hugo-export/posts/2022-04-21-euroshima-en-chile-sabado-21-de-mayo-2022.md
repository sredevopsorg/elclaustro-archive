---
title: 'Euroshima en Chile: Sábado 21 de Mayo 2022'
author: Niennor
type: post
date: 2022-04-21T16:27:08+00:00
url: /noticias/euroshima-en-chile-sabado-21-de-mayo-2022/
featured_image: /wp-content/uploads/2022/04/278143867_1639602806405241_4507035180442723711_n-920x613.jpg
categories:
  - Noticias

---
 

Presentamos a EUROSHIMA quienes llegan desde Argentina y -de manera exclusiva- conmemorando los 35 años del enigmático LP GALA y como parte del WORLD GOTH DAY 2022. Será una noche en el que será tocado en vivo el disco catalogado como el primer vinilo de dark, postpunk editado en Latinoamérica.

FECHA: 21 Mayo 2022  
VENUE: Ex Teatro Del Angel  
Huerfanos 786, Santiago, CHILE

VENTA DE ENTRADAS:  
<a href="https://www.passline.com/eventos/euroshima-en-chile-world-goth-day-2022-sabado-21-mayo?fbclid=IwAR0DwABjYTvIY9Pi77InYdApsf3iOy3PEDvx-YdE-NRVR_zycM5QBJ-e2uE" rel="noreferrer noopener" target="_blank">https://www.passline.com/&#8230;/euroshima-en-chile-world&#8230;</a>

Banda invitada: TEMPLE SOLAR (Post-Punk, Dark, CL)

Pre-Venta 1: $15.000  
Pre-Venta 2: $18.000

Post Fiesta a Cargo de † STIGMATA MARTYR †

Sublimes y lúgubres sonidos nos deleitarán en la pista de baile.  
¿Música?: BATCAVE &#8211; DEATH ROCK &#8211; GOTHIC ROCK &#8211; DARKWAVE &#8211; POST PUNK &#8211; COLD WAVE &#8211; MIMIMAL WAVE & Más&#8230;

NO sonará nada de Italo Disco, EBM, Industrial , electro dark y demás&#8230;

Djs Sets:  
◇ Dj SMILEBLACK  
◇ Dj REYNALDO

Evento en Facebook: <https://fb.me/e/3kCsKCuQy>
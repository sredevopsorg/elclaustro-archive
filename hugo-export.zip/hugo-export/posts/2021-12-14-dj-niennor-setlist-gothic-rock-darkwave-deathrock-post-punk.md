---
title: DJ Niennor – Setlist Gothic Rock, Darkwave, Deathrock, post punk
author: Niennor
type: post
date: 2021-12-14T22:38:20+00:00
excerpt: Selección de música del darkeo que solía poner en Release the Bats, Blondie, Bal le Duc, Teatro de Sombras y otros tantos eventos o antros en los que bailábamos con las manitos y desatábamos la pena gótica.
url: /repositorio-y-archivo-del-underground/dj-niennor-setlist-gothic-rock-darkwave-deathrock-post-punk/
featured_image: /wp-content/uploads/2021/12/1930465_21370959322_8153_n.jpg
categories:
  - Repositorio y archivo del Underground
  - Setlists
tags:
  - dj
  - niennor
  - release the bats

---
 

Selección de música del darkeo que solía poner en Release the Bats, Blondie, Bal le Duc, Teatro de Sombras y otros tantos eventos o antros en los que bailábamos con las manitos y desatábamos la pena gótica.

<div style="position: relative; padding-bottom: 100%; height: 0; overflow: hidden; max-width: 100%;">
  <div class="tidal-embed" data-type="p" data-id="b5730b46-85e4-4f49-8209-c71c1f6ab187">
  </div>
  
  <!-- -->
</div>
---
title: The Mission UK en sudamérica este 2012
author: Niennor
type: post
date: 2012-01-05T03:25:20+00:00
url: /sin-categoria/the-mission-uk-en-sudamerica-este-2012/
tumblr_elclaustro-blog_permalink:
  - https://elclaustro-blog.tumblr.com/post/15327380488/the-mission-uk-en-sudam%C3%A9rica-este-2012
tumblr_elclaustro-blog_id:
  - 15327380488
categories:
  - Noticias
  - Sin categoría
tags:
  - Argentina
  - Brasil
  - chile
  - En Vivo
  - The Mission UK

---
<figure class="tmblr-full" data-orig-height="333" data-orig-width="500"><img decoding="async" src="https://64.media.tumblr.com/fe48451b8edeb37efff160795ee45bef/785a715e1c2f3fca-7e/s540x810/0d39b42acd2adf0c0e6dab324a0e9fa9fa7188bc.jpg" data-orig-height="333" data-orig-width="500" /></figure> 

La banda inglesa **The Mission** volverá a **Chile** el próximo **25 de mayo**, comenzando aquí una **gira suramericana** que también tiene fechas confirmadas en Argentina y Brasil, y que se enmarcará en la celebración de sus **25 años de trayectoria**.

Fue la misma agrupación la que <a href="http://themissionuk.com/wp/2012/01/the-mission-in-south-america/#.TwUCaSNdwXo" target="_blank" rel="noopener">dio el anuncio</a> a través de su sitio web, dando por seguras las siguientes fechas:

**25 de mayo – Teatro Caupolicán, Santiago, Chile**  
26 de mayo – Teatro Colegiales, Buenos Aires, Argentina  
27 de mayo – Cine Joia, Sao Paulo, Brasil

En el comunicado, la banda menciona la posibilidad de agregar conciertos en Río De Janeiro el 31 de mayo y en Ciudad de México el 2 de junio, aunque estas presentaciones aún no están totalmente confirmadas.

La alineación que participará en esta gira está compuesta por Craig Adams, Simon Hinkler, Wayne Hussey y Mike Kelly, quienes a fines de 2011 se reunieron y volvieron a los escenarios para conmemorar el 25 aniversario de The Mission con una gira europea.

Aún no hay información disponible sobre la venta de entradas para el show en Chile. Seguiremos informando.</p>
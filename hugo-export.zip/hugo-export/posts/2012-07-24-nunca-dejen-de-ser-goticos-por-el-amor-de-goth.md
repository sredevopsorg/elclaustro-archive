---
title: Nunca dejen de ser góticos, por el amor de Goth.
author: Niennor
type: post
date: 2012-07-24T03:12:30+00:00
url: /columnas/comentarios/nunca-dejen-de-ser-goticos-por-el-amor-de-goth/
tumblr_elclaustro-blog_permalink:
  - https://elclaustro-blog.tumblr.com/post/27882872489/nunca-dejen-de-ser-g%C3%B3ticos-por-el-amor-de-goth
tumblr_elclaustro-blog_id:
  - 27882872489
categories:
  - Comentarios

---
Como bien decíamos con Amadeus, hemos llegado al <strike>pachangoth</strike> ultragoth (suena engrupido, pero en sentido literal significa más allá del goth), en el sentido de una complejidad cultural mayor a simples dogmas o paradigmas culturales establecidos.  
Saludos!
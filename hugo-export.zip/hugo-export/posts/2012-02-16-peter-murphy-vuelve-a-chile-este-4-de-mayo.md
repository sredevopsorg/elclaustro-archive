---
title: Peter Murphy vuelve a Chile este 4 de Mayo
author: Niennor
type: post
date: 2012-02-16T14:29:00+00:00
url: /sin-categoria/peter-murphy-vuelve-a-chile-este-4-de-mayo/
tumblr_elclaustro-blog_permalink:
  - https://elclaustro-blog.tumblr.com/post/17711123936/peter-murphy-vuelve-a-chile-este-4-de-mayo
tumblr_elclaustro-blog_id:
  - 17711123936
categories:
  - Noticias
  - Sin categoría

---
<img decoding="async" loading="lazy" align="left" height="261" src="https://64.media.tumblr.com/tumblr_lzhph8vY8O1r04xdq.jpg" width="261" />Una de las voces más aclamadas de la música británica vuelve por segunda vez a Santiago este Viernes 4 de Mayo, enmarcado en la gira de presentación de su más reciente trabajo titulado &ldquo;Ninth&rdquo;.

Las entradas estarán a la venta a principios de Marzo y aún no hay información respecto a los precios.

Peter Murphy saltó a la fama junto a Bauhaus a principios de los &lsquo;80, identificándose por su particular y lúgubre voz, para luego proseguir una exitosa carrera solista, que lo ha llevado a compartir escenario y estudio con importantes músicos de la escena internacional.

<div>
</div>
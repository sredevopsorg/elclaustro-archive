---
title: Entrevista a Das Ich en Cerro Santa Lucía
author: Niennor
type: post
date: 2011-09-05T04:55:15+00:00
url: /entrevistas/entrevista-a-das-ich-en-chile/
featured_image: /wp-content/uploads/unnamed-file.jpeg
categories:
  - Destacados
  - Entrevistas
tags:
  - Alemania
  - Cerro Santa Lucía
  - Das Ich
  - Entrevista
  - Entrevistas
format: video

---
<div class="is-layout-constrained wp-block-group">
  <p>
    Escrito por Amadeus en Septiembre &#8211; 6 &#8211; 2009
  </p><figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-4-3 wp-has-aspect-ratio">
  
  <div class="wp-block-embed__wrapper">
  </div></figure> 
  
  <p>
    Por ahí por el 2006, me encontraba yo terminando el semestre con mis compañeros (incluido mi compadre <strong>Phillipe</strong>, que murió la semana pasada, <em>godspeed, fella!</em>) cuando me llama la mina de turno para invitarme jotísticamente al concierto de <strong>Das Ich</strong>, al que no iba ir por andar sin ni uno, no haberme acreditado y haberme pasado como una semana en la casa del <strong>Nico Schmidt, Kamus</strong> incluido, editando el examen anual consistente en un video estilo <strong>CQC</strong> sobre nuestra casa de estudios, que nos valió el odio de todo el plantel administrativo y docente, ya que nos burlamos grotescamente de todos (si lo encuentro, lo subo de nuevo, después que me entreguen el titulo, obvio).
  </p>
  
  <p>
    Bueno, la cosa es que sudado, mal oliente y&nbsp; sin dinero, aproveche que aún existía el glorioso <em><strong>Tanque Claustriano</strong></em> y le dije a kamus que me arrojara a la <strong>Blondie</strong>…&nbsp; a la cual llegue casi justo a medianoche, como buen <em>goooootico </em>xD. Después de mamarme los arrumacos y frases clichés de la auspiciante, entramos al concierto que había empezado harían unos 10 minutos.
  </p>
  
  <p>
    Después de reirme de los multiples especímenes neo-nothing y electrocefalopodos reinantes cantando en un germánico chuña’s style, me acerqué care raja a la reja <em>no se comparan con el chi-cchipamogli!</em> y le dije al guardia que me dejara pasar a hablar con la mina que hacía de interprete, para pedirle que&nbsp; me dejara entrevistarlos. Pico, en pocas palabras, fue lo que me dijo el guardia poniendo cara de “<em>pa onde vay, ctm</em>?”. Esperé. Cuando termina el show, baja <strong>Ringo</strong>, le hago una seña y le digo en gestos <em>“can i talk with you?”</em> a lo que responde afirmativamente mientras le hace una seña al guardia, al que miro con cara&nbsp; de “<em>voy pa dentro, poh, y ke paza</em>?”.
  </p>
  
  <p>
    Lenguaje universal: cigarros, piscolas y vamos pelando a <strong><em>Fiction</em></strong> sentados en el costado de escenario. De ahí, backstage, más alcohol, salud, <em>proost y</em> demases. Conversa amena y luego a la pista a sacarse fotos con la masa. <strong>Bruno</strong> se rie y agarra pal webeo a la gente poniendo sus mejores caras para las fotos. Le mira las tetas a la Rox. <strong>Stefan</strong> baila con una tipa que no conozco, que lo tiene bien atrincado entre sus brazos. 2 segundos después el chico coopera con una de las, posteriormente, claustrianas más destacada.&nbsp; Ringo sigue fumando y bailando solo. De ahí, al hotel, nos vemos mañana, ahí hacemos la entrevista.
  </p>
  
  <p>
    11 am, y ahí estoy otra vez, con Kamus de camarografo, el <strong>Nico Ramirez</strong> de fotografo groupie, y la <strong>Rox</strong> porque es la Rox y quién le puede decir que no. El resultado, desaparecido durante más de 3 años en mis archivos, apareció mientras revisaba unas cajas en mi depa fronterizo donde <span style="text-decoration: line-through;"><em>trafico</em></span> vivo por ahora. Con semejante caña, semanas sin dormir ni comer como la gente y más algunos nervios weones, pregunté puras weás!!! Esto, debido a que antes de entrevistarlos, Ringo y Bruno hablan entre ellos y lo único que entiendo es “<em>primero se la hacemos a el</em>“. <em>OMFG! </em>nada en la vida es gratis, pero yo prefiero <em>RedCompra</em>! No, no era lo que yo pensaba. Se referían a entrevistarme ellos para su <strong>Documental “Harmonia Mundi</strong>” sobre el gotico en el mundo. Y yo, tendría que dar la <em>feroz y cañifera </em>cara por Chilito. After that, y después de que Ringo me confesara que el vivía con $45 lucas mensuales en la universidad y me tratara de <em>“filthy rich”</em> por mi presupuesto mensual, salimos al parquecito cerca del hotel, ladera del <strong>Santa Lucía</strong>, donde sucedió esto…Las advertencias están hechas: puras weás! xD
  </p>
  
  <p>
    <em>PD: la wea tiene subtitulos incrustados en las opciones de youtube</em>
  </p>
  
  <div class="attribution">
    (Source: <a style="pointer-events: none;" tabindex="-1" href="https://www.youtube.com/">https://www.youtube.com/</a>)
  </div>
</div>
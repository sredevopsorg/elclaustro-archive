---
title: 'Release the Bats: Undead, Undead Undead!!! Viernes 16 de Diciembre, Santa Filomena 126'
author: Niennor
type: post
date: 2011-11-15T17:43:00+00:00
url: /noticias/release-the-bats-undead-undead-undead-viernes/
tumblr_elclaustro-blog_permalink:
  - https://elclaustro-blog.tumblr.com/post/12841098841/release-the-bats-undead-undead-undead-viernes
tumblr_elclaustro-blog_id:
  - 12841098841
categories:
  - Noticias
format: gallery

---
<div id='gallery-1' class='gallery galleryid-148 gallery-columns-3 gallery-size-thumbnail'>
  <figure class='gallery-item'> 
  
  <div class='gallery-icon portrait'>
    <a href='https://elclaustro.cl/noticias/release-the-bats-undead-undead-undead-viernes/attachment/149/'><img width="150" height="150" src="https://elclaustro.cl/wp-content/uploads/2011/11/tumblr_lupqk8bcdm1r2fqrro1_640-150x150.jpg" class="attachment-thumbnail size-thumbnail" alt="" decoding="async" loading="lazy" srcset="https://elclaustro.cl/wp-content/uploads/2011/11/tumblr_lupqk8bcdm1r2fqrro1_640-150x150.jpg 150w, https://elclaustro.cl/wp-content/uploads/2011/11/tumblr_lupqk8bcdm1r2fqrro1_640-96x96.jpg 96w" sizes="(max-width: 150px) 100vw, 150px" /></a>
  </div></figure>
</div>

Release the Bats: Undead, Undead Undead!!! Viernes 16 de Diciembre, Santa Filomena 126

Vuelve la legendaria fiesta que desde el año 2006 ha profanado la tumba de los sonidos old school, deathrock, post punk y gothic rock. En esta ocasión El Claustro y Santiago Decay hemos compartido nicho fúnebre para traerles los sonidos clásicos y lo nuevo dentro de la escena underground, con la mano de los profanadores de tumbas: Gabrielle, Misantrophia, Amnesiac y Niennor, quienes harán crujir las lápidas y que los murciélagos dominen Santiago la noche del Viernes 16. Traiga sus flores secas para decorar la tumba de los muertos olvidados, la entrada al cementerio es de $2000 pesos del dinero de los vivos, pagados exclusivamente al sepulturero en la puerta del cementerio. Produce: El Claustro y Santiago Decay
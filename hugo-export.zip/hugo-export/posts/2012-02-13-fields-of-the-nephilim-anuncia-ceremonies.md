---
title: Fields of the Nephilim anuncia “Ceremonies”
author: Niennor
type: post
date: 2012-02-13T17:57:00+00:00
url: /sin-categoria/fields-of-the-nephilim-anuncia-ceremonies/
tumblr_elclaustro-blog_permalink:
  - https://elclaustro-blog.tumblr.com/post/17557931799/fields-of-the-nephilim-anuncia-ceremonies
tumblr_elclaustro-blog_id:
  - 17557931799
categories:
  - Noticias
  - Sin categoría
tags:
  - Fields of the Nephilim

---
<img decoding="async" align="left" src="http://www.fields-of-the-nephilim.com/files/stacks_image_336_1.png" />La legendaria banda Fields of the Nephilim acaba de revelar el primer track de su próximo album &ldquo;Ceremonies&rdquo;, disco que muestra una faceta más cargada al metal y sonidos más extremos.

El disco -que también viene en versión DVD- cuenta con los himnos de la banda en vivo, en una grabación realizada en el teatro Sheper&rsquo;s Bush Empire de Londres, presentación editada y dirigida por el mismo Carl McCoy.

Éste disco será el antecesor de un nuevo disco de estudio que será anunciado a fines de este año.

Aquí una muestra del DVD y CD en vivo:</p>
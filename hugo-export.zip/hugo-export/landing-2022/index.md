---
title: Landing 2022
author: Niennor
type: page
date: 2022-01-12T03:35:09+00:00
draft: true

---
<figure class="wp-block-embed alignfull is-type-rich is-provider-spotify wp-block-embed-spotify wp-embed-aspect-21-9 wp-has-aspect-ratio">

<div class="wp-block-embed__wrapper">
</div></figure> 

<ul class="wp-block-latest-posts__list wp-block-latest-posts">
  <li>
    <div class="wp-block-latest-posts__featured-image alignright">
      <img width="1024" height="587" src="https://elclaustro.cl/wp-content/uploads/2022/04/278143867_1639602806405241_4507035180442723711_n-1024x587.jpg" class="attachment-large size-large wp-post-image" alt="" decoding="async" loading="lazy" style="max-width:512px;max-height:512px;" srcset="https://elclaustro.cl/wp-content/uploads/2022/04/278143867_1639602806405241_4507035180442723711_n-1024x587.jpg 1024w, https://elclaustro.cl/wp-content/uploads/2022/04/278143867_1639602806405241_4507035180442723711_n-300x172.jpg 300w, https://elclaustro.cl/wp-content/uploads/2022/04/278143867_1639602806405241_4507035180442723711_n-768x440.jpg 768w, https://elclaustro.cl/wp-content/uploads/2022/04/278143867_1639602806405241_4507035180442723711_n.jpg 1440w" sizes="(max-width: 1024px) 100vw, 1024px" />
    </div>
    
    <a class="wp-block-latest-posts__post-title" href="https://elclaustro.cl/noticias/euroshima-en-chile-sabado-21-de-mayo-2022/">Euroshima en Chile: Sábado 21 de Mayo 2022</a><div class="wp-block-latest-posts__post-excerpt">
      Presentamos a EUROSHIMA quienes llegan desde Argentina y -de manera exclusiva- conmemorando los 35 años del enigmático LP GALA y como parte del WORLD GOTH DAY 2022. Será una noche en el que será tocado en vivo el disco catalogado como el primer vinilo de dark, postpunk editado en Latinoamérica. FECHA: 21 Mayo 2022VENUE: Ex Teatro Del AngelHuerfanos 786, Santiago, CHILE VENTA DE ENTRADAS:https://www.passline.com/&#8230;/euroshima-en-chile-world&#8230; Banda invitada: TEMPLE SOLAR (Post-Punk, Dark, CL) Pre-Venta 1: $15.000Pre-Venta 2: $18.000 Post Fiesta a Cargo de † STIGMATA MARTYR † Sublimes y lúgubres sonidos nos deleitarán en la pista de baile.¿Música?: BATCAVE &#8211; DEATH ROCK [&hellip;]
    </div>
  </li>
  
  <li>
    <div class="wp-block-latest-posts__featured-image alignright">
      <img width="851" height="315" src="https://elclaustro.cl/wp-content/uploads/2022/03/277555545_509345807550929_4471107181600591093_n.jpg" class="attachment-large size-large wp-post-image" alt="" decoding="async" loading="lazy" style="max-width:512px;max-height:512px;" srcset="https://elclaustro.cl/wp-content/uploads/2022/03/277555545_509345807550929_4471107181600591093_n.jpg 851w, https://elclaustro.cl/wp-content/uploads/2022/03/277555545_509345807550929_4471107181600591093_n-300x111.jpg 300w, https://elclaustro.cl/wp-content/uploads/2022/03/277555545_509345807550929_4471107181600591093_n-768x284.jpg 768w" sizes="(max-width: 851px) 100vw, 851px" />
    </div>
    
    <a class="wp-block-latest-posts__post-title" href="https://elclaustro.cl/noticias/dark-corp-tv-temporada-2-episodio-14/">Dark Corp TV &#8211; Temporada 2 Episodio 14</a><div class="wp-block-latest-posts__post-excerpt">
      Dark Corp vuelve y es un placer para nosotros poder compartir un trabajo de altísima calidad, de quienes continúan con un espíritu underground, dark y por sobre todo profesional y apasionado.
    </div>
  </li>
  
  <li>
    <div class="wp-block-latest-posts__featured-image alignright">
      <img width="1024" height="923" src="https://elclaustro.cl/wp-content/uploads/2022/02/a0751635646_10-1024x923.jpg" class="attachment-large size-large wp-post-image" alt="" decoding="async" loading="lazy" style="max-width:512px;max-height:512px;" srcset="https://elclaustro.cl/wp-content/uploads/2022/02/a0751635646_10-1024x923.jpg 1024w, https://elclaustro.cl/wp-content/uploads/2022/02/a0751635646_10-300x271.jpg 300w, https://elclaustro.cl/wp-content/uploads/2022/02/a0751635646_10-768x692.jpg 768w, https://elclaustro.cl/wp-content/uploads/2022/02/a0751635646_10.jpg 1200w" sizes="(max-width: 1024px) 100vw, 1024px" />
    </div>
    
    <a class="wp-block-latest-posts__post-title" href="https://elclaustro.cl/repositorio-y-archivo-del-underground/melhaller-amenti/">Melhaller &#8211; Amenti</a><div class="wp-block-latest-posts__post-excerpt">
    </div>
  </li>
  
  <li>
    <div class="wp-block-latest-posts__featured-image alignright">
      <img width="604" height="453" src="https://elclaustro.cl/wp-content/uploads/2021/12/1930465_21370959322_8153_n.jpg" class="attachment-large size-large wp-post-image" alt="" decoding="async" loading="lazy" style="max-width:512px;max-height:512px;" srcset="https://elclaustro.cl/wp-content/uploads/2021/12/1930465_21370959322_8153_n.jpg 604w, https://elclaustro.cl/wp-content/uploads/2021/12/1930465_21370959322_8153_n-300x225.jpg 300w, https://elclaustro.cl/wp-content/uploads/2021/12/1930465_21370959322_8153_n-124x93.jpg 124w" sizes="(max-width: 604px) 100vw, 604px" />
    </div>
    
    <a class="wp-block-latest-posts__post-title" href="https://elclaustro.cl/repositorio-y-archivo-del-underground/dj-niennor-setlist-gothic-rock-darkwave-deathrock-post-punk/">DJ Niennor &#8211; Setlist Gothic Rock, Darkwave, Deathrock, post punk</a><div class="wp-block-latest-posts__post-excerpt">
      Selección de música del darkeo que solía poner en Release the Bats, Blondie, Bal le Duc, Teatro de Sombras y otros tantos eventos o antros en los que bailábamos con las manitos y desatábamos la pena gótica.
    </div>
  </li>
  
  <li>
    <div class="wp-block-latest-posts__featured-image alignright">
      <img width="576" height="1024" src="https://elclaustro.cl/wp-content/uploads/2021/10/rtb-silke-576x1024.jpeg" class="attachment-large size-large wp-post-image" alt="" decoding="async" loading="lazy" style="max-width:512px;max-height:512px;" srcset="https://elclaustro.cl/wp-content/uploads/2021/10/rtb-silke-576x1024.jpeg 576w, https://elclaustro.cl/wp-content/uploads/2021/10/rtb-silke-169x300.jpeg 169w, https://elclaustro.cl/wp-content/uploads/2021/10/rtb-silke.jpeg 720w" sizes="(max-width: 576px) 100vw, 576px" />
    </div>
    
    <a class="wp-block-latest-posts__post-title" href="https://elclaustro.cl/noticias/release-the-bats-2021/">Release the Bats 2021</a><div class="wp-block-latest-posts__post-excerpt">
    </div>
  </li>
</ul>
---
title: Inicio
author: Niennor
type: page
date: 2021-03-26T03:11:02+00:00
draft: true
site-sidebar-layout:
  - default
site-content-layout:
  - default
theme-transparent-header-meta:
  - default
site-post-title:
  - disabled
ast-featured-img:
  - disabled
ast-breadcrumbs-content:
  - disabled

---
## El Claustro &#8211; info@elclaustro.cl {.has-text-align-center}

<div class="is-layout-flex wp-container-4 wp-block-columns">
  <div class="is-layout-flow wp-block-column" style="flex-basis:25%">
  </div>
  
  <div class="is-layout-flow wp-block-column" style="flex-basis:50%">
    <div class="fb-page" style="width:100%; display:flex;" data-href="https://www.facebook.com/elclaustrocl" data-tabs="timeline" data-width="500" data-height="" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="false">
      <blockquote cite="https://www.facebook.com/elclaustrocl" class="fb-xfbml-parse-ignore">
        <p>
          <a href="https://www.facebook.com/elclaustrocl">El Claustro Webmagazine</a>
        </p>
      </blockquote>
    </div>
  </div>
  
  <div class="is-layout-flow wp-block-column" style="flex-basis:25%">
  </div>
</div>